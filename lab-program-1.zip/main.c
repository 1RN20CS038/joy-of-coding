/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void accept(int *,int *);
void display (int *,int );
void insert_at_pos(int*,int*);
void delete_at_pos(int* ,int*);

int main()
{
    int a[20],n=0,ch;

    for(;;)  //infinite loop
    {
     printf("1. enter the value for array\n");
     printf("2. display\n");
     printf("3. insert at pos\n");
     printf("4. delete at pos\n");
     printf("5. exit \n");
     printf("enter the choice =");
     scanf("%d",&ch);
     switch(ch)
     {
        case 1 :
            accept (a,&n);  
            break;
        case 2 :
            display (a,n);  
            break;
        case 3 :
            insert_at_pos(a,&n); 
            break;
        case 4 :
            delete_at_pos(a,&n); 
            break;
         case 5 :    return (0);
     }

         }// end of for loop
}

    void accept(int *p,int *n)
    {
     int i;
     scanf("%d",n);  
       for(i=0;i<*n;i++)
        scanf("%d", (p+i) );  // &p[i]   == p+i
     }


void display (int *p,int n)
{
         int i;
          
      printf("Contents of array are\n");
     for(i=0;i<n;i++)
       printf("%d ",p[i]);
}

void insert_at_pos(int *p,int *n)
{
     int pos,ele,i;
     printf("enter the value pos=");
     scanf("%d",&pos);

     if (pos <= 0 || pos > (*n)+1)  // valid range for pos is 1 to n+1
     { printf("Invalid position\n"); return; }

     printf("enter the value ele=");
     scanf("%d",&ele);
     for(i=(*n)-1;i>=(pos-1);i--)
        p[i+1]=p[i];
     p[pos-1]= ele;
     (*n)++;
}

void delete_at_pos(int *p,int *n)
{
     int pos,i;
     printf("enter the value pos");
     scanf("%d",&pos);

     if (pos <= 0 || pos > (*n))
     { printf("Invalid position\n"); return; }

     for(i=pos-1;i<(*n);i++)
       p[i]=p[i+1];
     (*n)--;
}