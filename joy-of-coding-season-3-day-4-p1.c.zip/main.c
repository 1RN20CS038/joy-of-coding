//using stack to add books and remove from a box
#include<stdio.h>
#include<stdlib.h>
#define MAX 5
struct book
{
int id;
char name[40];
char author[50];
float price;
};
typedef struct book B;
void push(B *s,int *top)
{
if((*top)==MAX-1)
{ 
printf("box is full books cannot be added!\n");
return;
}
(*top)++;
printf("enter book details\n");
scanf("%d%s%s%f",&(s[*top].id),(s[*top].name),s[*top].author,&(s[*top].price));
}
void remov(B *s,int *top)
{
if((*top)==-1)
{
printf("box is empty,books cannot be removed\n");
return;
}
printf("the book removed is %d %s %s %f\n",s[*top].id,s[*top].name,s[*top].author,s[*top].price);
(*top)--;
}
void display(B *s,int top)
{
int i; 
if((top)==-1)
{
printf("box is empty,books cannot be removed\n");
return;
}
for(i=top;i>=0;i--)
printf(" %d %s %s %f\n",s[i].id,s[i].name,s[i].author,s[i].price); 
}
void main()
{
B s[5];
int top=-1,ch,n;
/*printf("enter no of books in box\n");
scanf("%d",&n);*/

for(;;)
{
    printf("1.push\n2.remove\n3.display\n");
scanf("%d",&ch);
switch(ch)
{
case 1:push(s,&top);break;
       case 2:remov(s,&top);break;
case 3:display(s,top);break;
default:exit(0);
}
}
}
