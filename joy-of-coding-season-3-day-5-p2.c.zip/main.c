//reverse list of odd numbers(linked list)
#include<stdio.h>
#include<stdlib.h>
struct node
{
struct node *llink; 
int num;
struct node *rlink;
};
typedef struct node N;
void insert(N *f)
{
    N *t,*l;
    t=(N*)malloc(sizeof(N));
    printf("enter the element\n");
    scanf("%d",&(t->num));
    t->llink=t->rlink=0; 
    if((f->rlink)==0)
    {
        f->rlink=t;
        return;
    }
    
        for(l=f->rlink;(l->rlink)!=0;l=l->rlink);
        l->rlink=t;
        t->llink=l;
        


}
void reverse(N *f)
{

N *t,*l,*p;
int temp;
for(l=f->rlink;(l->rlink)!=0;l=l->rlink);
for(t=f->rlink;(l->llink)!=(t->rlink);t=t->rlink)
//while()
{
temp=t->num;
t->num=l->num;
l->num=temp;
l=l->llink;
}
for(p=f->rlink;p!=0;p=p->rlink)
printf("%d\t",p->num);
printf("\n");

}
void display(N *f)
{
N *t;
for(t=f->rlink;t!=0;t=t->rlink)
printf("%d\t",t->num);
printf("\n");
}
int main()
{
    N f={.llink=0,.rlink=0};
    int n,i,ch;
    for(;;)
    {
    printf("1.insert n elements\n2.reverse\n3.display\n");
    printf("enter the choice\n");
    scanf("%d",&ch);
    switch(ch)
    {
        case 1:/*printf("enter num of elements\n");
            scanf("%d",&n);
            for(i=0;i<n;i++)
            {
                printf("%d",i);*/
                insert(&f);
                
                
            break;
        case 2:reverse(&f);break;
        case 3:display(&f);break;
        default:exit(0);
    }

}
return 0;
}
