/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#define MAX_ELE 4
void push(int*,int*);
void pop(int*,int*);
void display(int*,int);
void palin(void);
int main()
{
    int ch,top=-1,s[MAX_ELE];
    for(;;)
    {
        printf("\n1.push\n2.disply\n3.pop\n4.palindrome\nexit\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:push(s,&top);
                    break;
            case 2:display(s,top);
                    break;
            case 3:pop(s,&top);
                    break;
            case 4:palin();
                    break;
            default:exit(0);
        }
    }
}
void push(int *s,int *top)
{
    if((*top)==MAX_ELE-1)
    {
        printf("stack overflow\n");
        return ;
    }
    //else
    (*top)++;
    printf("enter the element\n");
    scanf("%d",&s[*top]);
}
void pop(int *s,int *top)
{
    if((*top)==-1)
    {
        printf("stack underflow\n");
        return;
    }
    printf("popped element is %d\n",s[*top]);
    (*top)--;
}
void display(int *s,int top)
{
    int i;
    if(top==-1)
    {
        printf("stack empty\n");
        return;
    }
    for(i=top;i>=0;i--)
        printf("%d\t",s[i]);
}
void palin()
{
    char a[30];
    int top,start=0,i,j;
    scanf("%s",a);
    top=strlen(a)-1;
    for(i=start,j=top;i<j;i++,j--)
    {
        if(a[i]!=a[j])
        {
            printf("not palindrome\n");
            return;
        }
    }
    printf("its an palindrome\n");
    
}
