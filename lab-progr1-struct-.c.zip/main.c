/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
struct student
{
    char nm[60];
    char usn[20];
    int marks;
};
typedef struct student st;

void accept(st *,int *);
void display (st *,int );
void insert_at_pos(st*,int*);
void delete_at_pos(st* ,int*);

int main()
{
    st a[20];
    int n=0,ch;

    for(;;)  //infinite loop
    {
     printf("1. enter the value for array\n");
     printf("2. display\n");
     printf("3. insert at pos\n");
     printf("4. delete at pos\n");
     printf("5. exit \n");
     printf("enter the choice =");
     scanf("%d",&ch);
     switch(ch)
     {
        case 1 :
            accept (a,&n);  
            break;
        case 2 :
            display (a,n);  
            break;
        case 3 :
            insert_at_pos(a,&n); 
            break;
        case 4 :
            delete_at_pos(a,&n); 
            break;
         case 5 :    return (0);
     }

         }// end of for loop
}

    void accept(st *p,int *n)
    {
     int i;
     scanf("%d",n);  
       for(i=0;i<*n;i++)
        scanf("%s%s%d",p[i].nm,p[i].usn,&(p[i].marks));  // &p[i]   == p+i
    }


void display (st *p,int n)
{
         int i;
          
      printf("Contents of array are\n");
     for(i=0;i<n;i++)
       printf("%s %s %d\n",p[i].nm,p[i].usn,p[i].marks);
}

void insert_at_pos(st *p,int *n)
{
     int pos,i;
     st ele;
     printf("enter the value pos=");
     scanf("%d",&pos);

     if (pos <= 0 || pos > (*n)+1)  // valid range for pos is 1 to n+1
     { printf("Invalid position\n"); return; }

     printf("enter the value ele=");
     scanf("%s%s%d",ele.nm,ele.usn,&(ele.marks));
     for(i=(*n)-1;i>=(pos-1);i--)
        p[i+1]=p[i];
     p[pos-1]= ele;
     (*n)++;
}

void delete_at_pos(st *p,int *n)
{
     int pos,i;
     printf("enter the value pos");
     scanf("%d",&pos);

     if (pos <= 0 || pos > (*n))
     { printf("Invalid position\n"); return; }

     for(i=pos-1;i<(*n);i++)
       p[i]=p[i+1];
     (*n)--;
}

