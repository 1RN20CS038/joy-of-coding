//finding the frequency of the most repeated character in a string
#include<stdio.h>
#include<string.h>
struct num
{
char c;
int cnt;
};
typedef struct num N;
int count(char *s,char c)
{
int j,p=0;
for(j=0;j<strlen(s);j++)
if(s[j]==c) 
p++;
return p;
}
int main()
{
char s[100],c;
N a[40];
N larg;
int i,j;
larg.cnt=0;
printf("enter the string\n");
scanf("%[^\n]s",s);
//for(i=0;i<strlen(s);i++)
//a[i].cnt=0;
for(i=0;i<strlen(s);i++)
{
a[i].c=s[i];
a[i].cnt=count(s,s[i]);
}
for(i=0;i<strlen(s);i++)
{
if(larg.cnt< a[i].cnt)
larg=a[i];
}
//for(i=0;i<strlen(s);i++)
//printf("%c %d\n",a[i].c,a[i].cnt);

printf("frequntly repeated letter is %c with a count of %d\n",larg.c,larg.cnt);


}
