/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<string.h>
#define MAX_ELE 30
int f(char s){
    switch(s)
    {
        case '+':
        case '-':return 2;
        case '*':
        case '/':return 4;
        case '$':
        case '^':return 5;
        case '(':return 0;
        case '#':return -1;
        default:return 8;
        
    }
}
int g(char s)
{
     switch(s)
    {
        case '+':
        case '-':return 1;
        case '*':
        case '/':return 3;
        case '$':
        case '^':return 6;
        case '(':return 9;
        case ')':return 0;
        default:return 7;
        
    }
}
int main()
{
    char c,s[MAX_ELE]={'#'};
    char inf[MAX_ELE]={"a/b-(c+d)"};
    char pf[MAX_ELE];
    int top=0,j=0,i;
    //printf("enter the infix expression\n");
    //scanf("%s",inf);
    for(i=0;i<strlen(inf);i++)
    {   
        c=inf[i];
        while(f(s[top])>g(c))
        {
            pf[j]=s[top];
            j++;
            top--;
        }
        if(f(s[top])!=g(inf[i]))
            s[++top]=inf[i];
        else
            top--;
    }
    for(;s[top]!='#';(top)--)
        pf[j++]=s[top];
    pf[j]='\0';
    printf("the postfix expression is %s\n",pf);


    return 0;
}    
            
        
    
    

