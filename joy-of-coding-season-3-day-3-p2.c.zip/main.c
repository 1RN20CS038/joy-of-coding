//find the subset of an given array,sum of the elements in the subset is equal to the given value of sum
#include<stdio.h>
int main()
{
    int sum=0,val,i,j,a[60],k,n;
    printf("enter the number of elements in an array\n");
    scanf("%d",&n);
    printf("enter the elements for array\n");
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    printf("enter the value of sum\n");
    scanf("%d",&val);
    for(i=0;i<n;i++)
    {
        sum=0;
        j=i+1;
        sum=sum+a[i]+a[j];
        while(j<n)
        {
            if(sum!=val)
            {
                j++;
                sum=sum+a[j];
            }
            else
                break;
        }
        if(sum==val)
            break;
    }
    for(k=i;k<=j;k++)
            printf("%d\t",a[k]);
           
    printf("\nRange of the indices is %d to %d\n",++i,++j);
    
        
    return 0;
}
