#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
//Complete the following function.


void calculate_the_maximum(int n, int k) {
    int i,j,r,p,x,m_and=0,m_or=0,m_xor=0;
    
    
    for(i=1;i<n;i++)
    {
        for(j=i+1;j<=n;j++)
            {
                r=i&j;
                p=i|j;
                x=i^j;
                if(r<k && r>m_and)
                {
                    m_and=r;
                }
                if(p<k && p>m_or)
                {
                    m_or=p;
                }
                
                if(x<k && x>m_xor)
                {
                    m_xor=x;    
                }
                               
            }
    }        
    
   
    printf("%d\n",m_and);
    printf("%d\n",m_or);
    printf("%d\n",m_xor);
}

int main() {
    int n, k;
  
    scanf("%d %d", &n, &k);
    calculate_the_maximum(n, k);
 
    return 0;
}
