//deleting duplicates in an array
#include<stdio.h>
#include<stdlib.h>
int* accept(int *n)
{
int *a,i;
printf("enter the num if ballons\n");
scanf("%d",n);
a=(int*)malloc(sizeof(int)*(*n));
for(i=0;i<(*n);i++)
scanf("%d",&a[i]);
return a;
}

void arrange(int *a,int *n)
{
int i,j;
for(i=0;i<*n;i++)
{
j=i+1; 

if(a[i]==a[j])
{ 
while(j<(*n))
{
a[j]=a[j+1];
j++;
}
(*n)--;
}

else
j++;

} 

}
void display(int *a,int n)
{
int i;
for(i=0;i<n;i++)
printf("%d\t",a[i]);
printf("\n");
}
void main()
{
int *a,*s[80],top=-1,n;
a=accept(&n);
arrange(a,&n);
display(a,n);

}
